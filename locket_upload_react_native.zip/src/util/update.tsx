import axios from 'axios';
import {version} from '../../package.json';

export const checkUpdateApk = async () => {
  const response = await axios.get(
  );
  const latestVersion = response.data.tag_name;
  const latestVersionNumber = latestVersion.replace('v', '');
  if (version !== latestVersionNumber) {
    return {
      latestVersion: latestVersionNumber,
      downloadUrl: response.data.assets[0].browser_download_url,
      updateInfo: 'APK_UPDATE_AVAILABLE',
      decriptionUpdate: response.data.body,
    };
  } else {
    return null;
  }
};
