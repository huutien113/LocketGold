export const nav = {
  login: 'login',
  home: 'home',
  resetPassword: 'resetPassword',
  accountInfo: 'accountInfo',
  crop: 'crop',
  setting: 'setting',
  camera: 'camera',
};
