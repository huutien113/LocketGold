import {Colors} from 'react-native-ui-lib';

export const ColorsInit = () => {
  Colors.loadColors({
    primary: '#FFB705',
  });
};
